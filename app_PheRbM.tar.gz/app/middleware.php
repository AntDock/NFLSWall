<?php

return[
    //session开启
    think\middleware\SessionInit::class
];